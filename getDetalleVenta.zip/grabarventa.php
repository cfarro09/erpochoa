<?php 
$nombre = $_POST['numcomprobante'];
echo $nombre;

?>
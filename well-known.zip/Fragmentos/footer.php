                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
 </div>
                            </div>
                            <!-- END REGIONAL STATS PORTLET-->
                        </div>
                        
                    </div>
                    
                    <!-- END PAGE BASE CONTENT -->
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <div class="text-center">
            <div class="page-footer-inner"> <?php echo $row_Conf_Sis['footer']; ?>
                
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
            
<?php
/*
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2007 Adobe Systems Incorporated
 * All Rights Reserved
 * 
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the 
 * terms of the Adobe license agreement accompanying it. If you have received this file from a 
 * source other than Adobe, then your use, modification, or distribution of it requires the prior 
 * written permission of Adobe.
 */

$res = array(
'PHP_GD_VERSION_ERROR' => 'Versi&oacute;n de GD err&oacute;nea: %s Necesita tener instalada la version 2.0 o superior',
'PHP_GD_ERROR' => 'No se puede inicializar nuevo flujo de imagen GD',
'FOLDER_ERROR' => 'No se puede crear im&aacute;gen captcha.',
'FOLDER_ERROR_D' => 'Cannot write in captcha temporary folder: %s',
);
?>
<?php
/*
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2007 Adobe Systems Incorporated
 * All Rights Reserved
 * 
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the 
 * terms of the Adobe license agreement accompanying it. If you have received this file from a 
 * source other than Adobe, then your use, modification, or distribution of it requires the prior 
 * written permission of Adobe.
 */

$res = array(
'SQL_ERROR' => '<strong>Error creando include din&aacute;mico:</strong><br/>%s<br/><strong>SQL:</strong><br/>%s<br/>',
'MISSING_FIELD' => '<strong>Error creando include din&aacute;mico:</strong><br/>El campo \'%s\' no esta en el juego de registros.<br/>',
'PHP_CHDIR_FAILED' => '<strong>Error incluyendo archivo:</strong><br/>No pudo cambiar el directorio a \'%s\' ejecute los permisos en "este" folder.<br/>',
);
?>